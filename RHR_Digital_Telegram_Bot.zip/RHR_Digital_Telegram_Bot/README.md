# RHR Digital Store Bot

Bot katalog Telegram untuk RHR Digital, dirancang agar bisa diatur lewat HP Android.

## Fitur
- Katalog 27 kategori produk dan varian awal.
- Harga jual diisi manual oleh admin.
- Varian dengan stok 0 tetap tampil.
- Pesanan dicatat di database SQLite dan notifikasi dikirim ke admin.
- Setelah memesan, pelanggan bisa lanjut ke WhatsApp CS.
- Admin dapat menambah kategori/varian, mengubah harga/stok, dan melihat pesanan.

## Penting
- Harga awal seluruh varian adalah Rp0 karena harga jual harus kamu tentukan sendiri.
- Stok awal disetel 0 supaya tidak menampilkan stok lama dari screenshot sebagai stok terkini.
- Pesanan bot belum otomatis membeli dari supplier dan belum menerima pembayaran otomatis. Admin tetap memeriksa stok, konfirmasi pembayaran, lalu memproses pesanan.
- Database lokal pada hosting gratis bisa hilang saat instance di-reset, kecuali hosting menyediakan persistent disk/database. Sebelum dipakai jualan sungguhan, pilih hosting dengan penyimpanan persisten atau pindahkan database ke layanan yang mendukungnya.
- Jangan masukkan token bot ke file publik, GitHub, atau chat.

## Cara mendapatkan Telegram User ID admin
1. Buka bot `@RHRDigitalStoreBot` di Telegram.
2. Kirim `/myid`.
3. Catat angka User ID yang muncul.

## Variabel lingkungan yang perlu disetel di hosting
- `BOT_TOKEN`: token dari @BotFather (rahasia).
- `ADMIN_IDS`: Telegram User ID admin, misalnya `123456789`.
- `WHATSAPP_NUMBER`: nomor CS format internasional tanpa `+`, contoh `6283875433379`.
- `DB_PATH`: opsional, lokasi database jika hosting punya persistent disk.

## Jalankan di komputer / lingkungan Python
```bash
pip install -r requirements.txt
export BOT_TOKEN="ISI_TOKEN_BOTFATHER"
export ADMIN_IDS="ISI_TELEGRAM_USER_ID"
export WHATSAPP_NUMBER="6283875433379"
python bot.py
```

## Perintah admin
- `/admin` — bantuan admin
- `/categories` — daftar kategori
- `/variants` — daftar varian beserta ID, harga, dan stok
- `/setprice ID HARGA` — set harga jual dalam rupiah, contoh `/setprice 12 15000`
- `/setstock ID STOK` — ubah stok, contoh `/setstock 12 5`
- `/addcategory id | nama kategori` — tambah kategori
- `/addvariant category_id | nama varian | harga | stok` — tambah varian
- `/orders` — lihat 15 pesanan terbaru
- `/orderstatus ID status` — ubah status pesanan

Contoh menambah produk:
`/addcategory vpn | VPN Premium`
`/addvariant vpn | Private 1 bulan | 12000 | 10`

## Catatan deployment
Gunakan layanan hosting yang mendukung proses Python worker berjalan terus-menerus dan penyimpanan persisten. Ketersediaan paket gratis berubah-ubah. Jika host menghentikan worker atau menghapus file lokal, bot/database tidak akan selalu aktif/tersimpan. Setelah deploy, uji `/start`, `/myid`, katalog, lalu satu pesanan percobaan.
