import os
import sqlite3
import urllib.parse
from datetime import datetime, timezone

from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, MessageHandler,
    ContextTypes, filters,
)

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_IDS = {
    int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",")
    if x.strip().isdigit()
}
WHATSAPP_NUMBER = "".join(c for c in os.getenv("WHATSAPP_NUMBER", "6283875433379") if c.isdigit())
DB_PATH = os.getenv("DB_PATH", "rhr_store.db")

CATEGORIES = {
    "email": ("Email Kosongan", ["Hotmail", "iCloud Promo"]),
    "gemini": ("AI Link Gemini Pro", ["3 bulan", "18 bulan"]),
    "alight": ("Alight Motion", ["Private 6 bulan", "Private 1 tahun"]),
    "amazon": ("Amazon Prime", ["Sharing", "Private"]),
    "apple": ("Apple Music", ["Famhead", "Indplan"]),
    "bstation": ("Bstation Premium", ["Share 1 bulan", "Share 3 bulan", "Share 1 tahun", "Private 1 bulan"]),
    "canvam": ("Canva Member", ["PRO Design 1 bulan", "PRO Design 3 bulan", "PRO Design 1 tahun", "Member Lifetime EDU"]),
    "canvao": ("Canva Owner", ["Head PRO Nogar", "Fullgar", "PRO 3B Nogar", "EDU Lifetime"]),
    "capcut": ("CapCut Pro", ["7 hari", "30 hari", "6 bulan"]),
    "disney": ("Disney+ Hotstar", ["Sharing", "Private"]),
    "hbo": ("HBO GO Max", ["Share Ultimate", "Private Ultimate", "Share Standard", "Private Standard"]),
    "iqiyi": ("IQIYI VIP", ["Share Basic", "Share Standard", "Share Premium", "Basic Private", "Standard Private", "Premium Private"]),
    "loklok": ("Loklok VIP", ["Basic Share", "Standar Share", "Private Basic 30D", "Private Basic 40D", "Private Standard 30D"]),
    "meitu": ("Meitu VIP", ["7 Hari VIP Android", "7 Hari VIP+ Alldev", "14 Hari VIP+ Alldev"]),
    "netflix": ("Netflix Premium", ["1 Profil 1 User", "Semi Private", "Single Screen", "Private Premium"]),
    "picsart": ("Picsart Pro", ["7 hari"]),
    "scribd": ("Scribd Premium", ["1 bulan"]),
    "spotify": ("Spotify Premium", ["Indplan 1 bulan", "Indplan 2 bulan", "Indplan 3B Nogar", "Famplan 1 bulan"]),
    "vidio": ("Vidio Platinum Private", ["Vidio TV 1 tahun", "Vid Mobile Fullgar", "Vid Alldev Student", "Vidio Alldev 1 bulan"]),
    "vision": ("Vision+ Premium", ["Private 1 bulan", "Share 1 bulan"]),
    "viu": ("VIU Premium", ["Antilimit 1 bulan", "Antilimit 6 bulan", "Antilimit 1 tahun", "Antilimit lifetime"]),
    "hma": ("VPN HMA", ["Private 1 bulan"]),
    "wetv": ("WeTV VIP", ["Share 6U 1 bulan", "Share 3U 1 bulan", "Share 3 bulan", "Private 1 bulan"]),
    "wink": ("Wink Private", ["7 hari VIP Android", "7 hari VIP+ Alldev", "14 hari VIP+ Alldev"]),
    "youku": ("Youku VIP", ["Share 1 bulan", "Share 3 bulan", "Private 1 bulan"]),
    "youtube": ("YouTube Premium", ["Famplan 1 bulan", "JasPay Head/Indplan", "Indplan 1 bulan Fullgar"]),
    "zoom": ("Zoom Pro", ["14 hari", "1 bulan"]),
}

def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS categories (
            id TEXT PRIMARY KEY, name TEXT NOT NULL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS variants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_id TEXT NOT NULL, name TEXT NOT NULL,
            price INTEGER NOT NULL DEFAULT 0, stock INTEGER NOT NULL DEFAULT 0,
            active INTEGER NOT NULL DEFAULT 1,
            FOREIGN KEY(category_id) REFERENCES categories(id))""")
        con.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
            username TEXT, customer_name TEXT, variant_id INTEGER,
            variant_name TEXT, category_name TEXT, quantity INTEGER,
            unit_price INTEGER, total INTEGER, status TEXT,
            created_at TEXT)""")
        for cid, (name, variants) in CATEGORIES.items():
            con.execute("INSERT OR IGNORE INTO categories(id,name) VALUES(?,?)", (cid, name))
            for v in variants:
                exists = con.execute(
                    "SELECT 1 FROM variants WHERE category_id=? AND name=?", (cid, v)
                ).fetchone()
                if not exists:
                    con.execute(
                        "INSERT INTO variants(category_id,name,price,stock) VALUES(?,?,0,0)",
                        (cid, v)
                    )

def rupiah(value):
    return "Rp" + f"{int(value):,}".replace(",", ".")

def is_admin(user_id):
    return user_id in ADMIN_IDS

def main_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🛍️ Lihat Katalog", callback_data="catalog")],
        [InlineKeyboardButton("📦 Cara Pemesanan", callback_data="howto"),
         InlineKeyboardButton("👨‍💻 Hubungi CS", url=f"https://wa.me/{WHATSAPP_NUMBER}")],
    ])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "👋 Selamat datang di *RHR Digital Store*\\!\n\n"
        "Pilih menu di bawah untuk melihat produk digital. "
        "Harga dan stok mengikuti informasi yang diatur admin.\n\n"
        "📌 Produk dengan harga Rp0 belum diberi harga jual; silakan hubungi CS."
    )
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=main_menu())

async def myid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        f"Telegram User ID kamu: `{update.effective_user.id}`",
        parse_mode="Markdown"
    )

async def admin_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Perintah ini khusus admin.")
        return
    await update.message.reply_text(
        "🛠️ *Panel Admin RHR Digital*\n\n"
        "/categories — daftar kategori\n"
        "/variants — daftar varian dan ID\n"
        "/setprice ID HARGA — contoh: `/setprice 12 15000`\n"
        "/setstock ID STOK — contoh: `/setstock 12 5`\n"
        "/addcategory id | nama kategori\n"
        "/addvariant category_id | nama varian | harga | stok\n"
        "/orders — pesanan terbaru\n"
        "/orderstatus ID status — contoh: `/orderstatus 4 diproses`\n"
        "/myid — lihat Telegram ID kamu\n\n"
        "Harga dalam rupiah. Harga 0 berarti belum ditetapkan.",
        parse_mode="Markdown"
    )

async def categories_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Perintah ini khusus admin."); return
    with connect() as con:
        rows = con.execute("SELECT id,name FROM categories ORDER BY name").fetchall()
    await update.message.reply_text("\n".join(f"`{r['id']}` — {r['name']}" for r in rows), parse_mode="Markdown")

async def variants_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Perintah ini khusus admin."); return
    with connect() as con:
        rows = con.execute("""SELECT v.id,c.name category,v.name,v.price,v.stock
                              FROM variants v JOIN categories c ON c.id=v.category_id
                              ORDER BY c.name,v.id""").fetchall()
    lines = [f"#{r['id']} | {r['category']} — {r['name']} | {rupiah(r['price'])} | stok {r['stock']}" for r in rows]
    # Telegram message length limit; send in chunks.
    chunk = ""
    for line in lines:
        if len(chunk) + len(line) + 1 > 3500:
            await update.message.reply_text(chunk); chunk = ""
        chunk += line + "\n"
    if chunk:
        await update.message.reply_text(chunk)

async def setprice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Perintah ini khusus admin."); return
    if len(context.args) != 2 or not all(x.isdigit() for x in context.args):
        await update.message.reply_text("Format: /setprice ID HARGA\nContoh: /setprice 12 15000"); return
    vid, price = map(int, context.args)
    with connect() as con:
        cur = con.execute("UPDATE variants SET price=? WHERE id=?", (price, vid))
    await update.message.reply_text("Harga berhasil diperbarui." if cur.rowcount else "ID varian tidak ditemukan.")

async def setstock(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Perintah ini khusus admin."); return
    if len(context.args) != 2 or not all(x.isdigit() for x in context.args):
        await update.message.reply_text("Format: /setstock ID STOK\nContoh: /setstock 12 5"); return
    vid, stock = map(int, context.args)
    with connect() as con:
        cur = con.execute("UPDATE variants SET stock=? WHERE id=?", (stock, vid))
    await update.message.reply_text("Stok berhasil diperbarui." if cur.rowcount else "ID varian tidak ditemukan.")

async def addcategory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Perintah ini khusus admin."); return
    raw = update.message.text.partition(" ")[2]
    parts = [p.strip() for p in raw.split("|", 1)]
    if len(parts) != 2 or not all(parts):
        await update.message.reply_text("Format: /addcategory id | nama kategori"); return
    try:
        with connect() as con:
            con.execute("INSERT INTO categories(id,name) VALUES(?,?)", (parts[0].lower().replace(" ", "_"), parts[1]))
        await update.message.reply_text("Kategori berhasil ditambahkan.")
    except sqlite3.IntegrityError:
        await update.message.reply_text("ID kategori sudah ada. Pakai ID lain.")

async def addvariant(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Perintah ini khusus admin."); return
    raw = update.message.text.partition(" ")[2]
    parts = [p.strip() for p in raw.split("|")]
    if len(parts) != 4 or not parts[0] or not parts[1] or not parts[2].isdigit() or not parts[3].isdigit():
        await update.message.reply_text("Format: /addvariant category_id | nama varian | harga | stok"); return
    with connect() as con:
        cat = con.execute("SELECT 1 FROM categories WHERE id=?", (parts[0],)).fetchone()
        if not cat:
            await update.message.reply_text("ID kategori tidak ditemukan. Cek /categories."); return
        con.execute("INSERT INTO variants(category_id,name,price,stock) VALUES(?,?,?,?)",
                    (parts[0], parts[1], int(parts[2]), int(parts[3])))
    await update.message.reply_text("Varian berhasil ditambahkan.")

async def orders_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Perintah ini khusus admin."); return
    with connect() as con:
        rows = con.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 15").fetchall()
    if not rows:
        await update.message.reply_text("Belum ada pesanan."); return
    lines = [f"#{r['id']} | {r['category_name']} — {r['variant_name']} x{r['quantity']} | {rupiah(r['total'])} | {r['status']} | {r['customer_name'] or '-'}" for r in rows]
    await update.message.reply_text("\n".join(lines))

async def orderstatus(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Perintah ini khusus admin."); return
    if len(context.args) < 2 or not context.args[0].isdigit():
        await update.message.reply_text("Format: /orderstatus ID status"); return
    oid, status = int(context.args[0]), " ".join(context.args[1:])
    with connect() as con:
        cur = con.execute("UPDATE orders SET status=? WHERE id=?", (status, oid))
    await update.message.reply_text("Status pesanan diperbarui." if cur.rowcount else "Pesanan tidak ditemukan.")

async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data
    if data == "catalog":
        with connect() as con:
            rows = con.execute("SELECT id,name FROM categories ORDER BY name").fetchall()
        buttons = [[InlineKeyboardButton(r["name"], callback_data=f"cat:{r['id']}")] for r in rows]
        buttons.append([InlineKeyboardButton("⬅️ Menu utama", callback_data="home")])
        await q.edit_message_text("🛍️ *Katalog RHR Digital*\nPilih kategori:", parse_mode="Markdown",
                                  reply_markup=InlineKeyboardMarkup(buttons))
    elif data == "home":
        await q.edit_message_text("🏠 *RHR Digital Store*\nPilih menu:", parse_mode="Markdown", reply_markup=main_menu())
    elif data == "howto":
        await q.edit_message_text(
            "📦 *Cara pemesanan*\n1. Pilih kategori dan varian.\n2. Tekan tombol pesan.\n"
            "3. Pesanan tercatat di bot dan admin menerima notifikasi.\n"
            "4. Lanjutkan ke WhatsApp CS untuk konfirmasi stok, pembayaran, dan proses.\n\n"
            "Jangan transfer sebelum detail pesanan dikonfirmasi admin.",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Menu utama", callback_data="home")]])
        )
    elif data.startswith("cat:"):
        cid = data.split(":", 1)[1]
        with connect() as con:
            cat = con.execute("SELECT name FROM categories WHERE id=?", (cid,)).fetchone()
            rows = con.execute("SELECT id,name,price,stock FROM variants WHERE category_id=? AND active=1 ORDER BY id", (cid,)).fetchall()
        buttons = []
        for r in rows:
            price_text = rupiah(r["price"]) if r["price"] > 0 else "Harga hubungi CS"
            stock_text = "Stok tersedia" if r["stock"] > 0 else "Stok 0 (konfirmasi CS)"
            buttons.append([InlineKeyboardButton(f"{r['name']} · {price_text}", callback_data=f"var:{r['id']}")])
        buttons.append([InlineKeyboardButton("⬅️ Kategori", callback_data="catalog")])
        await q.edit_message_text(f"📂 *{cat['name']}*\nPilih varian:\n\nStok 0 tetap ditampilkan; konfirmasi ke CS sebelum membayar.",
                                  parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))
    elif data.startswith("var:"):
        vid = int(data.split(":", 1)[1])
        with connect() as con:
            r = con.execute("""SELECT v.*,c.name category FROM variants v JOIN categories c ON c.id=v.category_id WHERE v.id=?""", (vid,)).fetchone()
        if not r:
            await q.edit_message_text("Varian tidak ditemukan."); return
        price = rupiah(r["price"]) if r["price"] > 0 else "Belum ditetapkan — hubungi CS"
        stock = str(r["stock"]) if r["stock"] > 0 else "0 (konfirmasi ke CS)"
        kb = []
        if r["price"] > 0:
            kb.append([InlineKeyboardButton("🛒 Pesan 1", callback_data=f"buy:{vid}:1"),
                       InlineKeyboardButton("🛒 Pesan 2", callback_data=f"buy:{vid}:2")])
            kb.append([InlineKeyboardButton("🛒 Pesan 3", callback_data=f"buy:{vid}:3")])
        kb.append([InlineKeyboardButton("💬 Tanya / pesan via WhatsApp", url=f"https://wa.me/{WHATSAPP_NUMBER}?text="+urllib.parse.quote(f"Halo RHR Digital, saya ingin tanya {r['category']} - {r['name']}. Harga: {price}. Stok: {stock}."))])
        kb.append([InlineKeyboardButton("⬅️ Kembali", callback_data=f"cat:{r['category_id']}")])
        await q.edit_message_text(
            f"📦 *{r['category']}*\nVarian: *{r['name']}*\nHarga: *{price}*\nStok: *{stock}*\n\n"
            "Harga dan stok perlu dikonfirmasi CS sebelum pembayaran.",
            parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb)
        )
    elif data.startswith("buy:"):
        _, v_id, qty_s = data.split(":")
        vid, qty = int(v_id), int(qty_s)
        user = q.from_user
        with connect() as con:
            r = con.execute("""SELECT v.*,c.name category FROM variants v JOIN categories c ON c.id=v.category_id WHERE v.id=?""", (vid,)).fetchone()
            if not r or r["price"] <= 0:
                await q.edit_message_text("Harga belum ditetapkan. Silakan hubungi CS."); return
            total = r["price"] * qty
            cur = con.execute("""INSERT INTO orders(user_id,username,customer_name,variant_id,variant_name,category_name,quantity,unit_price,total,status,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (user.id, user.username or "", user.full_name, vid, r["name"], r["category"], qty,
                 r["price"], total, "menunggu konfirmasi CS", datetime.now(timezone.utc).isoformat()))
            oid = cur.lastrowid
        wa_text = (
            f"Halo RHR Digital, saya mau konfirmasi pesanan #{oid}.%0A"
            f"Produk: {r['category']} - {r['name']}%0AJumlah: {qty}%0A"
            f"Harga per unit: {rupiah(r['price'])}%0ATotal: {rupiah(total)}%0A"
            f"Nama: {user.full_name}%0AUsername Telegram: @{user.username or '-'}"
        )
        await q.edit_message_text(
            f"✅ *Pesanan #{oid} tercatat!*\n\nProduk: {r['category']} — {r['name']}\n"
            f"Jumlah: {qty}\nTotal sementara: {rupiah(total)}\nStatus: menunggu konfirmasi CS.\n\n"
            "Tekan tombol WhatsApp untuk konfirmasi stok dan pembayaran. Jangan transfer sebelum admin mengonfirmasi.",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💬 Lanjut ke WhatsApp CS", url=f"https://wa.me/{WHATSAPP_NUMBER}?text={urllib.parse.quote(wa_text.replace('%0A','\n'))}")],
                [InlineKeyboardButton("🏠 Menu utama", callback_data="home")]
            ])
        )
        for admin_id in ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=(f"🆕 PESANAN #{oid}\nProduk: {r['category']} — {r['name']}\n"
                          f"Jumlah: {qty}\nHarga/unit: {rupiah(r['price'])}\nTotal: {rupiah(total)}\n"
                          f"Pembeli: {user.full_name}\nUser ID: {user.id}\nUsername: @{user.username or '-'}\n"
                          f"Status: menunggu konfirmasi CS")
                )
            except Exception:
                pass

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    print("Bot error:", context.error)

def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN belum diisi sebagai environment variable.")
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("myid", myid))
    app.add_handler(CommandHandler("admin", admin_help))
    app.add_handler(CommandHandler("categories", categories_cmd))
    app.add_handler(CommandHandler("variants", variants_cmd))
    app.add_handler(CommandHandler("setprice", setprice))
    app.add_handler(CommandHandler("setstock", setstock))
    app.add_handler(CommandHandler("addcategory", addcategory))
    app.add_handler(CommandHandler("addvariant", addvariant))
    app.add_handler(CommandHandler("orders", orders_cmd))
    app.add_handler(CommandHandler("orderstatus", orderstatus))
    app.add_handler(CallbackQueryHandler(callback))
    app.add_error_handler(error_handler)
    print("RHR Digital Store bot is running.")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
